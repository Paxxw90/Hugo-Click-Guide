#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/PlayerObject.hpp>
#include <Geode/ui/GeodeUI.hpp>
#include <Geode/utils/file.hpp>
#include "Timing.hpp"
#include <chrono>
#include <cstdio>
#ifdef GEODE_IS_WINDOWS
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
using namespace geode::prelude;

namespace {
std::filesystem::path macrosPath() {
    auto dir=Mod::get()->getSaveDir()/"macros";
    std::filesystem::create_directories(dir);
    return dir;
}
std::string localKey(int id, std::string const& name) {
    if(id>0)return std::to_string(id);
    // Stable local-level key; std::hash is not guaranteed stable across builds.
    std::uint64_t h=14695981039346656037ull;
    for(unsigned char c:name){h^=c;h*=1099511628211ull;}
    return "local-"+std::to_string(h);
}
void box(CCDrawNode* draw,float x,float y,float w,float h,ccColor4F fill,ccColor4F edge,float thickness=.5f) {
    CCPoint v[]={{x,y},{x+w,y},{x+w,y+h},{x,y+h}};
    draw->drawPolygon(v,4,fill,thickness,edge);
}
}

class $modify(HugoClickGuide, PlayLayer) {
    struct Fields {
        guide::Macro macro;
        guide::Recorder recorder;
        guide::Judge judge;
        std::array<std::vector<guide::Note>,2> tracks;
        std::array<bool,2> held{};
        std::string key;
        int levelID=0;
        std::string levelName;
        std::string message="Carga una macro o graba un intento";
        CCNodeRGBA* root=nullptr;
        CCDrawNode* draw=nullptr;
        CCLabelBMFont* status=nullptr;
        CCLabelBMFont* scoreLabel=nullptr;
        bool ready=false, enabled=true, showBars=true, showLane=true;
        bool resetting=false;
        std::array<bool,5> keys{};
        double offset=0, ahead=2, laneWindow=1.2, lastClock=-1, lastStatus=-1;
        double lastScoreTime=-100;
        float alpha=.20f;
        int maxNotes=32;
        guide::Score lastScore;
        CCPoint lastPosition={0,0};
        float velocity=0;
        bool havePosition=false;
        double previousDraw=-1;
    };
    double clockNow() const { return m_gameState.m_levelTime; }
    double macroNow() { return clockNow()-m_fields->offset; }
    void message(std::string text) {m_fields->message=std::move(text);m_fields->lastStatus=-1;}
    void settings() {
        auto mod=Mod::get();
        m_fields->enabled=mod->getSettingValue<bool>("enabled");
        m_fields->showBars=mod->getSettingValue<bool>("show-bars");
        m_fields->showLane=mod->getSettingValue<bool>("show-lane");
        m_fields->offset=mod->getSettingValue<double>("offset-ms")/1000.;
        m_fields->ahead=mod->getSettingValue<double>("look-ahead");
        m_fields->laneWindow=mod->getSettingValue<double>("lane-window");
        m_fields->judge.perfectMs=mod->getSettingValue<double>("perfect-ms");
        m_fields->judge.goodMs=std::max(m_fields->judge.perfectMs,mod->getSettingValue<double>("ok-ms"));
        m_fields->maxNotes=static_cast<int>(mod->getSettingValue<int64_t>("max-notes"));
        m_fields->alpha=static_cast<float>(mod->getSettingValue<double>("opacity")/100.);
        m_fields->judge.reset(macroNow());
        m_fields->held={};
        m_fields->lastScore={};
        m_fields->lastStatus=-1;
    }
    void useMacro(guide::Macro macro) {
        m_fields->macro=std::move(macro);
        for(auto& t:m_fields->tracks)t.clear();
        for(auto n:m_fields->macro.notes)m_fields->tracks[n.player].push_back(n);
        m_fields->judge.load(m_fields->macro,macroNow());
        m_fields->lastScore={};
        m_fields->held={};
    }
    bool init(GJGameLevel* level,bool replay,bool skip) {
        if(!PlayLayer::init(level,replay,skip))return false;
        if(skip || !m_uiLayer)return true;
        m_fields->levelID=level->m_levelID.value();
        m_fields->levelName=std::string(level->m_levelName.c_str());
        m_fields->key=localKey(m_fields->levelID,m_fields->levelName);
        m_fields->root=CCNodeRGBA::create();
        // Screen-space overlay keeps colour triggers from tinting the guide.
        m_fields->root->setCascadeColorEnabled(false);
        m_fields->root->setCascadeOpacityEnabled(false);
        m_uiLayer->addChild(m_fields->root,200);
        m_fields->draw=CCDrawNode::create();
        m_fields->root->addChild(m_fields->draw);
        auto win=CCDirector::sharedDirector()->getWinSize();
        m_fields->status=CCLabelBMFont::create("Click Guide", "chatFont.fnt");
        m_fields->status->setScale(.42f);
        m_fields->status->setAnchorPoint({0.f,1.f});
        m_fields->status->setPosition({8.f,win.height-35.f});
        m_fields->root->addChild(m_fields->status,1);
        m_fields->scoreLabel=CCLabelBMFont::create("", "chatFont.fnt");
        m_fields->scoreLabel->setScale(.55f);
        m_fields->scoreLabel->setAnchorPoint({0.f,0.f});
        m_fields->scoreLabel->setPosition({8.f,15.f});
        m_fields->root->addChild(m_fields->scoreLabel,1);
        auto menu=CCMenu::create(); menu->setPosition({0,0});
        m_fields->root->addChild(menu,2);
        auto add=[&](char const* title,SEL_MenuHandler handler,float x) {
            auto sprite=ButtonSprite::create(title);
            sprite->setScale(.43f);
            auto item=CCMenuItemSpriteExtra::create(sprite,this,handler);
            item->setPosition({x,win.height-14.f}); menu->addChild(item);
        };
        add("GUIA",menu_selector(HugoClickGuide::onToggle),40);
        add("REC",menu_selector(HugoClickGuide::onRecord),95);
        add("GUARDAR",menu_selector(HugoClickGuide::onSave),157);
        add("CARGAR",menu_selector(HugoClickGuide::onLoad),225);
        add("CARPETA",menu_selector(HugoClickGuide::onFolder),296);
        add("AJUSTES",menu_selector(HugoClickGuide::onSettings),365);
        m_fields->ready=true;
        settings();
        loadReference(false);
        return true;
    }
    void onToggle(CCObject*) {
        m_fields->enabled=!m_fields->enabled;
        Mod::get()->setSettingValue<bool>("enabled",m_fields->enabled);
        m_fields->judge.reset(macroNow());
        message(m_fields->enabled?"Guia activada":"Guia desactivada");
    }
    void onSettings(CCObject*) {pauseGame(false);openSettingsPopup(Mod::get());}
    void onFolder(CCObject*) {
        try{file::openFolder(macrosPath());}
        catch(std::exception const& e){message(e.what());}
    }
    void onRecord(CCObject*) {
        if(m_fields->recorder.active) {
            m_fields->recorder.finish(clockNow());
            message("Grabacion detenida. F8 / GUARDAR para conservarla");
            return;
        }
        if(!m_fields->recorder.macro.edges.empty()) {
            message("Guarda primero la grabacion pendiente con F8"); return;
        }
        if(m_isPracticeMode || m_startPosObject) {
            message("Graba desde el inicio, fuera de practica y sin StartPos"); return;
        }
        resetLevel();
        m_fields->recorder.begin(m_fields->levelID,m_fields->levelName);
        m_fields->held={};
        message("REC: jugando desde el inicio. F7 detiene / F8 guarda");
    }
    void onSave(CCObject*) {
        auto& rec=m_fields->recorder;
        if(rec.active)rec.finish(clockNow());
        if(rec.macro.edges.empty()) {message("No hay grabacion. Pulsa REC o F7");return;}
        try {
            auto dir=macrosPath();
            auto stamp=std::chrono::duration_cast<std::chrono::milliseconds>(
                std::chrono::system_clock::now().time_since_epoch()).count();
            auto path=dir/(m_fields->key+"-"+std::to_string(stamp)+".json");
            guide::saveMacro(rec.macro,path);
            Mod::get()->setSavedValue("reference-"+m_fields->key,path.filename().string());
            useMacro(rec.macro);
            rec.macro={};
            message("Guardada como referencia. Reinicia para seguirla");
        } catch(std::exception const& e) {message(std::string("No se guardo: ")+e.what());}
    }
    void loadReference(bool explicitRequest) {
        if(m_fields->recorder.active) {message("Deten la grabacion antes de cargar");return;}
        try {
            auto dir=macrosPath();
            auto selected=Mod::get()->getSavedValue<std::string>("reference-"+m_fields->key,"");
            std::vector<std::filesystem::path> candidates;
            // Explicit load prioritizes newly supplied files; startup remembers
            // the last successful reference, including our own recordings.
            auto addSelected=[&] {
                if(!selected.empty() && std::filesystem::path(selected).filename()==std::filesystem::path(selected))
                    candidates.push_back(dir/selected);
            };
            if(!explicitRequest)addSelected();
            for(auto ext:{".gdr.json",".gdr",".json",".xd"})candidates.push_back(dir/(m_fields->key+ext));
            if(explicitRequest)addSelected();
            for(auto const& path:candidates) {
                if(!std::filesystem::is_regular_file(path))continue;
                auto m=guide::loadMacro(path);
                if(m.levelID>0 && m_fields->levelID>0 && m.levelID!=m_fields->levelID)
                    throw std::runtime_error("La macro indica otro ID de nivel");
                useMacro(std::move(m));
                Mod::get()->setSavedValue("reference-"+m_fields->key,path.filename().string());
                message("Referencia: "+path.filename().string());return;
            }
            message("Sin macro: CARPETA > "+m_fields->key+".gdr / .json, o REC");
        } catch(std::exception const& e) {message(std::string("Error al cargar: ")+e.what());}
    }
    void onLoad(CCObject*) {loadReference(true);}
    void inputEdge(PlayerObject* player,bool down) {
        if(!m_fields->ready || m_fields->resetting || m_isPaused || !player || player->m_isDead)return;
        int p=player==m_player1?0:(player==m_player2?1:-1);
        if(p<0 || (p==1 && !m_gameState.m_isDualMode))return;
        if(m_fields->held[p]==down)return;
        m_fields->held[p]=down;
        m_fields->recorder.input(clockNow(),down,p);
        if(down && m_fields->enabled && !m_fields->recorder.active && !m_fields->macro.notes.empty()) {
            m_fields->judge.expire(macroNow(),m_gameState.m_isDualMode);
            m_fields->lastScore=m_fields->judge.press(macroNow(),p);
            m_fields->lastScoreTime=clockNow();m_fields->lastStatus=-1;
        }
    }
    void resetGuide() {
        if(!m_fields->ready)return;
        m_fields->judge.reset(macroNow());
        m_fields->held={};m_fields->lastScore={};
        m_fields->lastClock=clockNow();m_fields->havePosition=false;
        m_fields->previousDraw=-1;m_fields->lastStatus=-1;
    }
    void resetLevel() {
        if(m_fields->ready && m_fields->recorder.active) {
            m_fields->recorder.finish(clockNow());
            message("Intento grabado. F8 para guardar antes de grabar otro");
        }
        m_fields->resetting=true;
        PlayLayer::resetLevel();
        m_fields->resetting=false;
        resetGuide();
    }
    void loadFromCheckpoint(CheckpointObject* checkpoint) {
        m_fields->resetting=true;
        PlayLayer::loadFromCheckpoint(checkpoint);
        m_fields->resetting=false;
        resetGuide();
    }
    void resume() {PlayLayer::resume();if(m_fields->ready)settings();}
    void destroyPlayer(PlayerObject* player,GameObject* object) {
        PlayLayer::destroyPlayer(player,object);
        if(m_fields->ready && player && player->m_isDead && m_fields->recorder.active) {
            m_fields->recorder.finish(clockNow());
            message("Grabacion parcial lista. F8 para guardar");
        }
    }
    void levelComplete() {
        if(m_fields->ready && m_fields->recorder.active) {
            m_fields->recorder.finish(clockNow());
            onSave(nullptr);
        }
        PlayLayer::levelComplete();
    }
    void pollKeys() {
#ifdef GEODE_IS_WINDOWS
        DWORD pid=0;GetWindowThreadProcessId(GetForegroundWindow(),&pid);
        if(pid!=GetCurrentProcessId()) {m_fields->keys={};return;}
        int codes[]={VK_F6,VK_F7,VK_F8,VK_F9,VK_F10};
        for(int i=0;i<5;++i) {
            bool down=(GetAsyncKeyState(codes[i])&0x8000)!=0;
            bool edge=down&&!m_fields->keys[i];m_fields->keys[i]=down;
            if(!edge)continue;
            if(i==0)onToggle(nullptr);
            else if(i==1)onRecord(nullptr);
            else if(i==2)onSave(nullptr);
            else if(i==3)onLoad(nullptr);
            else onFolder(nullptr);
        }
#endif
    }
    void drawGuide(double now) {
        auto draw=m_fields->draw; draw->clear();
        if(!m_fields->enabled || m_fields->macro.notes.empty() || m_fields->recorder.active)return;
        auto win=CCDirector::sharedDirector()->getWinSize();
        bool dual=m_gameState.m_isDualMode;
        auto root=m_fields->root;
        float floor=48.f, ceiling=win.height-60.f;
        float laneBottom=65.f,laneTop=win.height*.72f;
        // Two independent lanes for dual mode. The trapezoid recreates the
        // visual rhythm-lane idea without depending on third-party artwork.
        if(m_fields->showLane) for(int p=0;p<(dual?2:1);++p) {
            float center=28.f+p*41.f;
            CCPoint poly[]={{center-15,laneBottom},{center+15,laneBottom},
                {center+6,laneTop},{center-6,laneTop}};
            draw->drawPolygon(poly,4,{.02f,.035f,.05f,.7f},.7f,{.45f,.55f,.65f,.7f});
            draw->drawSegment({center-18,laneBottom},{center+18,laneBottom},1.2f,{1.f,.8f,.25f,1.f});
        }
        int drawn=0;
        for(int p=0;p<(dual?2:1);++p) {
            auto player=p==0?m_player1:m_player2;
            if(!player)continue;
            auto anchor=root->convertToNodeSpace(player->getParent()->convertToWorldSpace(player->getPosition()));
            ccColor4F color=p==0?ccColor4F{.15f,.95f,.48f,1.f}:ccColor4F{1.f,.3f,.7f,1.f};
            if(m_fields->showBars && !m_isPlatformer) {
                draw->drawSegment({anchor.x,floor},{anchor.x,ceiling},.5f,{1,1,1,.55f});
                box(draw,anchor.x-4,anchor.y-4,8,8,{0,0,0,0},{1,1,1,.9f});
            }
            auto const& track=m_fields->tracks[p];
            auto it=std::lower_bound(track.begin(),track.end(),now-.06,
                [](auto const& note,double t){return note.end<t;});
            for(;it!=track.end() && it->start<=now+std::max(m_fields->ahead,m_fields->laneWindow);++it) {
                if(drawn>=m_fields->maxNotes)break;
                ++drawn;
                double a=it->start-now,b=it->end-now;
                bool hold=it->hasRelease && it->end-it->start>=.045;
                if(m_fields->showBars && !m_isPlatformer && std::abs(m_fields->velocity)>1.f && a<=m_fields->ahead) {
                    // Time projection at current measured speed; it is NOT a
                    // prediction of future portals, trajectories or safe hitboxes.
                    auto base=player->getPosition();
                    CCPoint deltaPoint={base.x+m_fields->velocity,base.y};
                    auto projected=root->convertToNodeSpace(player->getParent()->convertToWorldSpace(deltaPoint));
                    float pxPerSecond=projected.x-anchor.x;
                    float x1=anchor.x+static_cast<float>(std::max(a,hold?0.:-.06))*pxPerSecond;
                    float x2=hold?anchor.x+static_cast<float>(b)*pxPerSecond:x1+2.f;
                    float left=std::max(0.f,std::min(x1,x2)),right=std::min(win.width,std::max(x1,x2));
                    if(right>left && b>=-.06) {
                        auto fill=color;fill.a=m_fields->alpha;
                        auto edge=color;edge.a=.7f;
                        box(draw,left,floor,right-left,ceiling-floor,fill,edge,.35f);
                        if(x1>=0 && x1<=win.width) {
                            draw->drawSegment({x1,floor},{x1,ceiling},.8f,color);
                            box(draw,x1-2.5f,anchor.y-2.5f,5,5,{0,0,0,0},color);
                        }
                    }
                }
                if(m_fields->showLane && a<=m_fields->laneWindow && b>=-.06) {
                    float center=28.f+p*41.f;
                    auto y=[&](double t){return laneBottom+static_cast<float>(std::clamp(t/m_fields->laneWindow,0.,1.))*(laneTop-laneBottom);};
                    auto width=[&](float py){return 15.f-9.f*(py-laneBottom)/(laneTop-laneBottom);};
                    float y1=y(a),y2=hold?y(b):y1+3.f;
                    float w1=width(y1),w2=width(y2);
                    CCPoint v[]={{center-w1,y1},{center+w1,y1},{center+w2,y2},{center-w2,y2}};
                    auto fill=color;fill.a=.65f;
                    draw->drawPolygon(v,4,fill,.6f,color);
                }
            }
        }
    }
    void updateLabels(double now) {
        if(m_fields->lastStatus>=0 && now-m_fields->lastStatus<.10)return;
        m_fields->lastStatus=now;
        std::string status=m_fields->recorder.active?"REC | ":(m_fields->enabled?"GUIA | ":"OFF | ");
        status+=m_fields->message;
        m_fields->status->setString(status.c_str());
        auto win=CCDirector::sharedDirector()->getWinSize();
        float full=m_fields->status->getContentSize().width;
        m_fields->status->setScale(std::min(.42f,(win.width-16.f)/std::max(1.f,full)));
        auto s=m_fields->lastScore;
        char line[192];
        char const* verdict="";
        switch(s.verdict) {
            case guide::Verdict::Perfect: verdict="PERFECT";break;
            case guide::Verdict::Good: verdict="OK";break;
            case guide::Verdict::Miss: verdict="MISS";break;
            case guide::Verdict::Extra: verdict="EXTRA";break;
            default: break;
        }
        if(now-m_fields->lastScoreTime>1.)verdict="";
        std::snprintf(line,sizeof(line),"%s %+.1f ms | P:%d OK:%d MISS:%d EXTRA:%d",verdict,
            *verdict?s.errorMs:0.,m_fields->judge.perfect,m_fields->judge.good,
            m_fields->judge.missed,m_fields->judge.extra);
        m_fields->scoreLabel->setString(line);
        m_fields->scoreLabel->setVisible(m_fields->enabled && !m_fields->macro.notes.empty() && !m_fields->recorder.active);
        m_fields->scoreLabel->setColor(s.verdict==guide::Verdict::Perfect?ccColor3B{70,255,130}:
            s.verdict==guide::Verdict::Good?ccColor3B{255,215,75}:ccColor3B{255,130,130});
    }
    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        if(!m_fields->ready)return;
        double now=clockNow();
        // postUpdate can be entered multiple times for physics substeps. Use
        // gameplay clock, never a fixed 1/480 increment or a frame counter.
        if(now<m_fields->lastClock-1e-6)resetGuide();
        m_fields->lastClock=now;
        pollKeys();
        now=clockNow();
        if(m_player1 && !m_player1->m_isDead && now!=m_fields->previousDraw) {
            auto pos=m_player1->getPosition();
            double elapsed=now-m_fields->previousDraw;
            if(m_fields->havePosition && elapsed>0 && elapsed<.10) {
                double dx=pos.x-m_fields->lastPosition.x;
                double speed=dx/elapsed;
                m_fields->velocity=std::abs(dx)<30 && std::abs(speed)<3000 ? static_cast<float>(speed):0.f;
            } else m_fields->velocity=0;
            m_fields->havePosition=true;m_fields->lastPosition=pos;m_fields->previousDraw=now;
        }
        if(m_fields->enabled && !m_fields->recorder.active && m_player1 && !m_player1->m_isDead) {
            if(m_fields->judge.expire(macroNow(),m_gameState.m_isDualMode)) {
                m_fields->lastScore={guide::Verdict::Miss,0,0};
                m_fields->lastScoreTime=now;m_fields->lastStatus=-1;
            }
        }
        drawGuide(macroNow());
        updateLabels(now);
    }
};
class $modify(HugoClickGuidePlayer, PlayerObject) {
    bool pushButton(PlayerButton button) {
        if(button==PlayerButton::Jump)
            if(auto pl=PlayLayer::get())static_cast<HugoClickGuide*>(pl)->inputEdge(this,true);
        return PlayerObject::pushButton(button);
    }
    bool releaseButton(PlayerButton button) {
        if(button==PlayerButton::Jump)
            if(auto pl=PlayLayer::get())static_cast<HugoClickGuide*>(pl)->inputEdge(this,false);
        return PlayerObject::releaseButton(button);
    }
};
