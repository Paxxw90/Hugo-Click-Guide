#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <filesystem>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
#include "../third_party/json.hpp"

namespace guide {
using Json = nlohmann::json;
constexpr std::size_t MaxEvents = 100000;
constexpr std::uintmax_t MaxBytes = 16 * 1024 * 1024;
struct Edge { double time; bool down; int player; };
struct Note { double start, end; int player; bool hasRelease; };
struct Macro {
    std::string name;
    int levelID = 0;
    double duration = 0;
    std::vector<Edge> edges;
    std::vector<Note> notes;
};
inline double finiteNumber(Json const& j, char const* name) {
    if (!j.is_number()) throw std::runtime_error(std::string(name)+": debe ser numerico");
    double v = j.get<double>();
    if (!std::isfinite(v)) throw std::runtime_error(std::string(name)+": valor no finito");
    return v;
}
inline void buildNotes(Macro& m) {
    std::stable_sort(m.edges.begin(), m.edges.end(), [](auto a, auto b){return a.time < b.time;});
    m.notes.clear();
    std::array<int,2> held = {-1,-1};
    for (auto const& e : m.edges) {
        int& i = held.at(e.player);
        if (e.down && i == -1) {
            i = static_cast<int>(m.notes.size());
            m.notes.push_back({e.time,e.time,e.player,false});
        } else if (!e.down && i != -1) {
            m.notes[i].end = e.time;
            m.notes[i].hasRelease = true;
            i = -1;
        }
    }
    // An unmatched press remains a tap: never fabricate a long hold.
    for (auto const& e : m.edges) m.duration = std::max(m.duration,e.time);
}
inline Macro parseMacro(Json const& j) {
    if (!j.is_object() || !j.contains("inputs") || !j["inputs"].is_array())
        throw std::runtime_error("Se requiere un objeto con inputs[]");
    auto const& inputs = j["inputs"];
    if (inputs.size() > MaxEvents) throw std::runtime_error("Demasiadas entradas (maximo 100000)");
    Macro m;
    bool native = j.value("format",std::string{}) == "hugo.click-guide.v1";
    double rate = 0;
    if (!native) {
        if (!j.contains("framerate")) throw std::runtime_error("GDR requiere framerate de la MACRO");
        rate = finiteNumber(j["framerate"],"framerate");
        if (rate < 1 || rate > 100000) throw std::runtime_error("framerate fuera de rango");
    }
    if (j.contains("level")) {
        auto const& l = j["level"];
        if (!l.is_object()) throw std::runtime_error("level invalido");
        m.levelID = l.value("id",0);
        m.name = l.value("name",std::string{});
    }
    if (j.contains("duration")) {
        m.duration = finiteNumber(j["duration"],"duration");
        if (m.duration < 0 || m.duration > 86400) throw std::runtime_error("Duracion fuera de rango");
    }
    for (auto const& v : inputs) {
        if (!v.is_object()) throw std::runtime_error("Entrada invalida");
        if (!native && v.value("btn",v.value("button",1)) != 1) continue;
        if (!v.contains("down") || !v["down"].is_boolean()) throw std::runtime_error("down debe ser booleano");
        double t = 0;
        int p = 0;
        if (native) {
            t = finiteNumber(v.at("time"),"time");
            if (!v.contains("player") || !v["player"].is_number_integer())
                throw std::runtime_error("player debe ser 1 o 2");
            p = v["player"].get<int>()-1;
        } else {
            double frame = finiteNumber(v.at("frame"),"frame");
            if (frame < 0 || std::floor(frame) != frame) throw std::runtime_error("frame invalido");
            t = frame/rate;
            p = v.value("2p",v.value("player2",false)) ? 1 : 0;
        }
        if (t < 0 || t > 86400 || p < 0 || p > 1) throw std::runtime_error("Tiempo o jugador fuera de rango");
        m.edges.push_back({t,v["down"].get<bool>(),p});
    }
    if (m.edges.empty()) throw std::runtime_error("La macro no contiene saltos");
    buildNotes(m);
    if (m.notes.empty()) throw std::runtime_error("La macro no contiene pulsaciones");
    return m;
}
inline Macro loadMacro(std::filesystem::path const& path) {
    auto bytes = std::filesystem::file_size(path);
    if (!bytes || bytes > MaxBytes) throw std::runtime_error("Archivo vacio o mayor de 16 MiB");
    std::ifstream f(path,std::ios::binary);
    if (!f) throw std::runtime_error("No se pudo abrir el archivo");
    std::vector<std::uint8_t> data(static_cast<std::size_t>(bytes));
    if (!f.read(reinterpret_cast<char*>(data.data()), static_cast<std::streamsize>(data.size())))
        throw std::runtime_error("Lectura incompleta");
    auto first = std::find_if(data.begin(),data.end(),[](auto c){return c!=' ' && c!='\r' && c!='\n' && c!='\t';});
    Json j;
    if (first != data.end() && *first == '{') {
        // Reject deeply nested input before recursive parsing.
        int depth=0; bool quoted=false,escaped=false;
        for (auto c : data) {
            if (quoted) { if (escaped) escaped=false; else if (c=='\\') escaped=true; else if(c=='"') quoted=false; }
            else if(c=='"') quoted=true;
            else if(c=='{' || c=='[') { if (++depth>32) throw std::runtime_error("JSON demasiado anidado"); }
            else if(c=='}' || c==']') --depth;
        }
        j=Json::parse(data);
    } else {
        // GDR v1 binary uses MessagePack. SAX bounds nesting and prevents
        // allocation from an untrusted declared array length.
        struct Guard : nlohmann::json_sax<Json> {
            int depth=0; std::size_t count=0;
            bool tick(){return ++count < 2000000;}
            bool null() override{return tick();}
            bool boolean(bool) override{return tick();}
            bool number_integer(number_integer_t) override{return tick();}
            bool number_unsigned(number_unsigned_t) override{return tick();}
            bool number_float(number_float_t,string_t const&) override{return tick();}
            bool string(string_t& s) override{return s.size()<=MaxBytes && tick();}
            bool binary(binary_t&) override{return false;}
            bool start_object(std::size_t n) override{return ++depth<=32 && (n==std::size_t(-1)||n<=MaxEvents) && tick();}
            bool key(string_t&) override{return tick();}
            bool end_object() override{--depth;return true;}
            bool start_array(std::size_t n) override{return ++depth<=32 && (n==std::size_t(-1)||n<=MaxEvents) && tick();}
            bool end_array() override{--depth;return true;}
            bool parse_error(std::size_t,std::string const&,nlohmann::detail::exception const&) override{return false;}
        } guard;
        if (!Json::sax_parse(data,&guard,Json::input_format_t::msgpack))
            throw std::runtime_error("Formato no compatible. Usa GDR v1, GDR JSON o grabacion propia; GDR2/SLC no admitidos");
        j=Json::from_msgpack(data);
    }
    return parseMacro(j);
}
inline Json serialize(Macro const& m) {
    Json j={{"format","hugo.click-guide.v1"},{"level",{{"id",m.levelID},{"name",m.name}}},
        {"duration",m.duration},{"inputs",Json::array()}};
    for(auto e:m.edges) j["inputs"].push_back({{"time",e.time},{"down",e.down},{"player",e.player+1}});
    return j;
}
// New recordings use unique names; saving cannot overwrite a good reference.
inline void saveMacro(Macro const& m,std::filesystem::path const& path) {
    if (std::filesystem::exists(path)) throw std::runtime_error("El archivo ya existe");
    auto tmp=path; tmp += ".tmp";
    {
        std::ofstream f(tmp,std::ios::binary|std::ios::trunc);
        if (!f) throw std::runtime_error("No se pudo crear el archivo");
        f<<serialize(m).dump(2); f.flush();
        if(!f) throw std::runtime_error("No se pudo guardar la grabacion");
    }
    std::filesystem::rename(tmp,path);
}

enum class Verdict {None,Perfect,Good,Miss,Extra};
struct Score { Verdict verdict=Verdict::None; double errorMs=0; int player=0; };
class Judge {
    std::array<std::vector<double>,2> presses;
    std::array<std::vector<bool>,2> consumed;
    std::array<std::size_t,2> cursor{};
public:
    int perfect=0, good=0, missed=0, extra=0;
    double perfectMs=8, goodMs=33;
    void load(Macro const& m,double start=0) {
        for(auto& v:presses)v.clear();
        for(auto const& n:m.notes)presses[n.player].push_back(n.start);
        reset(start);
    }
    void reset(double start) {
        perfect=good=missed=extra=0;
        for(int p=0;p<2;++p) {
            consumed[p].assign(presses[p].size(),false);
            cursor[p]=std::lower_bound(presses[p].begin(),presses[p].end(),start-1e-7)-presses[p].begin();
            for(std::size_t i=0;i<cursor[p];++i)consumed[p][i]=true;
        }
    }
    bool expire(double now,bool dual) {
        bool any=false;
        for(int p=0;p<2;++p) {
            auto& c=cursor[p];
            while(c<presses[p].size() && presses[p][c]<now-goodMs/1000.-1e-9) {
                if(!consumed[p][c] && (p==0||dual)) {++missed;any=true;}
                consumed[p][c]=true; ++c;
            }
        }
        return any;
    }
    Score press(double now,int p) {
        auto& times=presses.at(p);
        auto begin=std::lower_bound(times.begin(),times.end(),now-goodMs/1000.-1e-9);
        std::size_t best=times.size(); double diff=std::numeric_limits<double>::infinity();
        for(auto it=begin;it!=times.end() && *it<=now+goodMs/1000.+1e-9;++it) {
            std::size_t i=it-times.begin();
            if(!consumed[p][i] && std::abs(now-*it)<diff) {diff=std::abs(now-*it);best=i;}
        }
        if(best==times.size()) {++extra;return {Verdict::Extra,0,p};}
        consumed[p][best]=true;
        double error=(now-times[best])*1000.;
        if(std::abs(error)<=perfectMs+1e-6) {++perfect;return {Verdict::Perfect,error,p};}
        ++good; return {Verdict::Good,error,p};
    }
};
class Recorder {
    std::array<bool,2> held{};
public:
    bool active=false;
    Macro macro;
    void begin(int id,std::string name) {macro={};macro.levelID=id;macro.name=std::move(name);held={};active=true;}
    void input(double t,bool down,int p) {
        if(!active || !std::isfinite(t) || t<0 || t>86400 || p<0 || p>1 || held[p]==down)return;
        if(macro.edges.size()>=MaxEvents-2) {finish(t);return;}
        held[p]=down;macro.edges.push_back({t,down,p});
    }
    void finish(double t) {
        if(!active)return;
        for(int p=0;p<2;++p)if(held[p])macro.edges.push_back({t,false,p});
        held={};active=false;macro.duration=t;buildNotes(macro);
    }
};
} // namespace guide
