#include "../src/Timing.hpp"
#include <iostream>
#include <functional>
#include <cstdlib>
int checks=0;
void check(bool ok,char const* msg){++checks;if(!ok){std::cerr<<"FAIL: "<<msg<<'\n';std::exit(1);}}
void rejects(std::function<void()> fn,char const* msg){bool threw=false;try{fn();}catch(std::exception const&){threw=true;}check(threw,msg);}
bool near(double a,double b){return std::abs(a-b)<1e-7;}
guide::Json native(){return {{"format","hugo.click-guide.v1"},{"inputs",guide::Json::array({
    {{"time",1.0},{"down",true},{"player",1}},
    {{"time",1.5},{"down",false},{"player",1}},
    {{"time",2.0},{"down",true},{"player",2}},
    {{"time",2.05},{"down",false},{"player",2}},
    {{"time",3.0},{"down",true},{"player",1}}})}};}
int main(){
 using namespace guide;
 auto m=parseMacro(native());
 check(m.notes.size()==3,"hold pairing and dual");
 check(near(m.notes[0].end,1.5),"release time");
 check(!m.notes[2].hasRelease && near(m.notes[2].start,m.notes[2].end),"unmatched press not invented hold");
 auto j=native();j["inputs"].push_back({{"time",1.1},{"down",true},{"player",1}});
 check(parseMacro(j).notes.size()==3,"duplicate down ignored");
 std::reverse(j["inputs"].begin(),j["inputs"].end());
 check(near(parseMacro(j).notes[0].start,1),"out of order sorted");
 for(int fps:{60,120,240,480,1000,1200}){
  Json g={{"framerate",fps},{"inputs",Json::array({
   {{"frame",fps},{"btn",1},{"2p",false},{"down",true}},
   {{"frame",fps*2},{"btn",1},{"2p",false},{"down",false}},
   {{"frame",fps},{"btn",2},{"2p",false},{"down",true}}})}};
  auto r=parseMacro(g);check(r.notes.size()==1 && near(r.notes[0].start,1)&&near(r.notes[0].end,2),"GDR rate-independent seconds and movement ignored");
 }
 auto wrong=native();wrong["inputs"][0]["time"]=-1;
 rejects([&]{parseMacro(wrong);},"negative time");
 wrong=native();wrong["inputs"][0]["player"]=3;
 rejects([&]{parseMacro(wrong);},"invalid player");
 wrong=native();wrong["inputs"][0]["time"]=std::numeric_limits<double>::infinity();
 rejects([&]{parseMacro(wrong);},"nonfinite time");
 wrong=native();wrong["inputs"][0]["down"]="true";
 rejects([&]{parseMacro(wrong);},"wrong boolean type");
 rejects([&]{parseMacro(Json{{"inputs",Json::array()},{"framerate",0}});},"zero rate");
 rejects([&]{parseMacro(Json{{"inputs",Json::array()}});},"missing rate");
 check(parseMacro(serialize(m)).edges.size()==m.edges.size(),"native roundtrip");
 auto dir=std::filesystem::temp_directory_path()/"hugo-guide-unit-tests";
 std::filesystem::create_directories(dir);
 auto file=dir/"roundtrip.json";std::filesystem::remove(file);
 saveMacro(m,file);check(loadMacro(file).notes.size()==3,"file roundtrip");
 rejects([&]{saveMacro(m,file);},"no silent overwrite");
 auto binary=dir/"gdr.gdr";
 Json g={{"framerate",480},{"inputs",Json::array({{{"frame",480},{"btn",1},{"2p",false},{"down",true}}})}};
 auto bytes=Json::to_msgpack(g);{std::ofstream f(binary,std::ios::binary);f.write(reinterpret_cast<char*>(bytes.data()),bytes.size());}
 check(near(loadMacro(binary).notes[0].start,1),"GDR MessagePack");
 {std::ofstream f(binary,std::ios::binary);f<<"not a macro";}
 rejects([&]{loadMacro(binary);},"corrupt binary rejected");
 {std::ofstream f(binary);f<<"{\"x\":";for(int i=0;i<40;++i)f<<'[';}
 rejects([&]{loadMacro(binary);},"deep JSON bounded");
 Judge judge;judge.load(m);
 check(judge.press(1.008,0).verdict==Verdict::Perfect,"inclusive perfect boundary");
 check(judge.press(1.008,0).verdict==Verdict::Extra,"one consumption per reference press");
 check(judge.press(2.,0).verdict==Verdict::Extra,"wrong dual stream");
 check(judge.press(2.025,1).verdict==Verdict::Good,"dual scoring");
 judge.expire(3.034,true);judge.expire(4,true);
 check(judge.missed==1,"miss expires once");
 judge.reset(2.5);
 check(judge.perfect==0 && judge.missed==0,"reset tally");
 judge.expire(2.6,true);check(judge.missed==0,"checkpoint skips previous notes");
 check(judge.press(3,0).verdict==Verdict::Perfect,"checkpoint later note still scored");
 judge.reset(0);judge.expire(2.1,false);check(judge.missed==1,"inactive P2 notes not counted as misses");
 for(int fps:{60,120,240,480,1000}){
  judge.load(m);
  for(int frame=0;frame<=fps;++frame)judge.expire(double(frame)/fps,true);
  check(judge.press(1,0).verdict==Verdict::Perfect,"render update rate does not shift clock");
 }
 Recorder rec;rec.begin(42,"Test");rec.input(1,true,0);rec.input(1.1,true,0);rec.input(1.2,true,1);rec.finish(2);
 check(rec.macro.edges.size()==4,"stop recording closes both held inputs once");
 check(!rec.active && rec.macro.notes.size()==2,"recording finalized");
 rec.input(3,true,0);check(rec.macro.edges.size()==4,"inactive recorder ignores input");
 rec.begin(42,"Test");check(rec.macro.edges.empty(),"new attempt clears old recording");
 std::filesystem::remove_all(dir);
 std::cout<<"PASS: "<<checks<<" checks\n";
}
